from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from .mychatbot import mychat
from .scrap import data

def chatbot(request):
    response = None

    if request.method == 'POST':
        user_input = request.POST.get('user_input')
        if user_input:
            response = mychat(user_input)  # Call your chatbot function

    context = {'response': response}
    return render(request, 'index.html', context)

def scrap(request):
    response = None

    if request.method == 'POST':
        user_input = request.POST.get('webname')
        if user_input:
            data(user_input) 
            response="done"
        else:
            response="not done"

    context = {'response': response}
    return render(request, 'scrap.html', context)