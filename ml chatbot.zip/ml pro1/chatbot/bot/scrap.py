import requests
from bs4 import BeautifulSoup
import pandas as pd

def data(webname):
    url = webname
    response = requests.get(url)
    html_content = response.content


    soup = BeautifulSoup(html_content, 'html.parser')

    # Extract data using BeautifulSoup's methods
    title = soup.title.text
    faq= soup.find('ul', class_='wow fadeInUp') 
    Ques_ans= faq.find_all('li')

    # print(Ques_ans)
    qa = []

    for i in Ques_ans:
        question = i.find('a').text
        answer = i.find('p').text
        ques_data = {'question': question,'answer': answer.strip()}
        qa.append(ques_data)
    # print(qa)


    df = pd.DataFrame(qa)
    df.to_csv('./bot/quesans.csv', index=False)