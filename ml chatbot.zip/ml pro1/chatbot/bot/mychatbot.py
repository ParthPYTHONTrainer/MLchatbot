import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
# from scrap import data
def mychat(user_input):
    # data()
    df = pd.read_csv('./bot/quesans.csv')
    questions = df['question']
    answers = df['answer']


    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(questions)


    model = MultinomialNB()
    model.fit(X, answers)

    user_input_vectorized = vectorizer.transform([user_input])
    predicted_answer = model.predict(user_input_vectorized)
    # print(f"Bot: {predicted_answer[0]}")
    return predicted_answer[0]