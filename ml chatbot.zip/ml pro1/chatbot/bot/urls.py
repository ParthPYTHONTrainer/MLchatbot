from django.urls import path
from . import views


urlpatterns = [
    path('', views.chatbot, name='bot'),
    path('scrap/', views.scrap, name='scrap'),

    # Other URL patterns for your chatbot app
]